package acc.br.bean.life.cycle.beans;

public class Weapon {
    private String name;

    public Weapon(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
